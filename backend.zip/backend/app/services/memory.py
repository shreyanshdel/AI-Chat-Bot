from typing import List, Dict
from datetime import datetime
from app.integrations.vector_db.qdrant import QdrantClient
from app.integrations.redis_client import RedisClient

class HierarchicalMemory:
    """
    Three-Tier Memory Architecture for the Student's Digital Twin.
    1. Episodic: Chronological conversation history.
    2. Semantic: Conceptual mastery and knowledge graph nodes.
    3. Procedural: Learning style and behavior patterns.
    """
    def __init__(self, student_id: str):
        self.student_id = student_id
        self.vector_db = QdrantClient()
        self.cache = RedisClient()

    async def recall_episodic(self, query: str) -> List[str]:
        """Retrieve past conversations relevant to current query."""
        return await self.vector_db.search(
            collection=f"episodic_{self.student_id}",
            query=query,
            limit=5
        )

    async def update_semantic_state(self, concept: str, mastery_score: float):
        """Update the student's mastery level for a specific curriculum node."""
        # This feeds into the GAT-based Knowledge Trace
        key = f"semantic:{self.student_id}:{concept}"
        await self.cache.set(key, {
            "score": mastery_score,
            "last_updated": datetime.now().isoformat()
        })

    async def get_procedural_style(self) -> str:
        """Infer best teaching style (Visual, Analytical, Narrative)."""
        # Patterns analyzed via transformer on interaction logs
        style = await self.cache.get(f"procedural:{self.student_id}:style")
        return style or "Analytical" # Default

    async def store_experience(self, interaction: Dict):
        """Archive a full agentic loop experience for future reflection."""
        # Store in episodic vector DB
        await self.vector_db.upsert(
            collection=f"episodic_{self.student_id}",
            points=[interaction]
        )
