import time
import json
import asyncio
from typing import List, Optional, AsyncGenerator
from motor.motor_asyncio import AsyncIOMotorClient

try:
    from sentence_transformers import SentenceTransformer, util
    HAS_SENTENCE_TRANSFORMERS = True
except ImportError:
    HAS_SENTENCE_TRANSFORMERS = False

from app.core.config.settings import settings
from app.ml.intent_classifier import IntentClassifier
from app.services.llm_service import LLMService

class ChatEngine:
    def __init__(self, mongo_db: AsyncIOMotorClient):
        self.db = mongo_db
        self.model = SentenceTransformer('all-MiniLM-L6-v2') if HAS_SENTENCE_TRANSFORMERS else None
        self.intent_classifier = IntentClassifier()
        self.llm = LLMService()
        
        self.banned_fillers = [
            "That's an interesting question",
            "Let me look into that for you",
            "As a StudyMate AI, I can help you with",
            "Great question"
        ]

    async def get_conversation_history(self, conversation_id: str, limit: int = 20) -> List[dict]:
        """Load last N messages from MongoDB."""
        cursor = self.db.conversations.find({"_id": conversation_id}).sort("timestamp", -1).limit(limit)
        history = await cursor.to_list(length=limit)
        return history[::-1]

    async def check_repetition(self, draft_response: str, history: List[dict]) -> bool:
        """
        Compute similarity between draft and last 3 assistant messages.
        """
        last_assistant_msgs = [m["content"] for m in history if m["role"] == "assistant"][-3:]
        if not last_assistant_msgs:
            return False

        if not self.model:
            for prev_msg in last_assistant_msgs:
                if prev_msg == draft_response:
                    return True
            return False

        draft_embedding = self.model.encode(draft_response, convert_to_tensor=True)
        for prev_msg in last_assistant_msgs:
            prev_embedding = self.model.encode(prev_msg, convert_to_tensor=True)
            similarity = util.cos_sim(draft_embedding, prev_embedding).item()
            if similarity > 0.85:
                return True
        return False

    def get_system_prompt(self, feature_hint: Optional[str] = None) -> str:
        """
        Build the production-grade StudyMate AI system prompt based on the 4-layer teaching structure.
        """
        prompt = (
            "You are StudyMate AI, a patient and brilliant tutor. Your goal is to explain concepts "
            "so clearly that students understand them in one read. Follow this 4-LAYER STRUCTURE:\n"
            "1. THE HOOK: 1-2 sentences connecting the concept to a real-world, relatable situation (games, movies, life).\n"
            "2. THE SIMPLE EXPLANATION: 2-4 sentences in plain, jargon-free language using a concrete analogy.\n"
            "3. THE PROPER EXPLANATION: The main body with clear sub-headings. Define every technical term in brackets "
            "the first time it appears (e.g., 'Inertia [the tendency to resist motion]'). Use bullet points and "
            "worked examples for math/science. Anticipate where students get confused.\n"
            "4. THE ANCHOR: A memorable summary line, a common student mistake to avoid, or a mnemonic. "
            "Then, always ask a gentle follow-up question to keep the learning going.\n\n"
            "STYLE RULES:\n"
            "- Use 'you' and 'we'; sound like a friendly senior.\n"
            "- Use analogies relentlessly (Atoms = solar systems, RAM = desk).\n"
            "- No walls of text; use short paragraphs and bold key terms.\n"
            "- SHOW, DON'T JUST TELL: Every formula must have a worked example with numbers plugged in.\n"
            "- NEVER use fillers: 'Great question!', 'As an AI...', 'Interesting doubt!'. Go straight to the hook.\n"
            "- If the grade level is unknown, default to Class 10 depth."
        )
        if feature_hint:
            prompt += f"\n\nSPECIFIC FEATURE GUIDANCE: This query relates to {feature_hint}. Prioritize relevant pedagogical methods."
        return prompt

    async def stream_response(
        self,
        conversation_id: str,
        user_message: str,
        feature_hint: Optional[str] = None
    ) -> AsyncGenerator[str, None]:
        """
        Stream SSE chunks for: reasoning trace, expert assignment, text generation, suggested follow-ups.
        """
        start_time = time.time()
        
        # 1. Yield initial reasoning thinking trace
        yield f"event: thinking\ndata: {json.dumps({'text': 'Analyzing topic and pedagogical route', 'status': 'active'})}\n\n"
        await asyncio.sleep(0.5)
        yield f"event: thinking\ndata: {json.dumps({'text': 'Analyzing topic and pedagogical route', 'status': 'done'})}\n\n"
        
        yield f"event: thinking\ndata: {json.dumps({'text': 'Retrieving relevant CBSE/NCERT curriculum guides', 'status': 'active'})}\n\n"
        await asyncio.sleep(0.4)
        yield f"event: thinking\ndata: {json.dumps({'text': 'Retrieving relevant CBSE/NCERT curriculum guides', 'status': 'done'})}\n\n"

        # 2. Determine subject & route to expert badge
        q = user_message.lower()
        subject = 'General Science'
        expert_name = 'General Science Specialist'
        badge_color = 'bg-blue-50 text-blue-800 border-blue-200'
        pulse_color = 'bg-blue-500'
        suggested_followups = [
            "Explain this in more detail",
            "Give me an interactive quiz on this",
            "How does this relate to CBSE board exams?"
        ]

        if "photo" in q or "plant" in q or "leaf" in q or "biology" in q:
            subject = 'Biology'
            expert_name = 'Biology Expert'
            badge_color = 'bg-green-50 text-forest border-green-200'
            pulse_color = 'bg-green-500'
            suggested_followups = [
                "Solve a board-style question on this",
                "What happens to plants at night?",
                "Connect this to cellular respiration"
            ]
        elif "gravit" in q or "newton" in q or "physics" in q or "force" in q:
            subject = 'Physics'
            expert_name = 'Physics Expert'
            badge_color = 'bg-orange-50 text-terracotta border-orange-200'
            pulse_color = 'bg-orange-500'
            suggested_followups = [
                "Why doesn't the moon fall into the earth?",
                "What is the difference between mass and weight?",
                "Solve a numerical on gravity calculation"
            ]

        # Yield assigned expert metadata
        yield f"event: expert\ndata: {json.dumps({'name': expert_name, 'subject': subject, 'badgeColor': badge_color, 'pulseColor': pulse_color})}\n\n"
        
        # Load conversation history
        history = await self.get_conversation_history(conversation_id)
        
        # Generate System Prompt
        system_prompt = self.get_system_prompt(feature_hint)
        
        # Stream response chunks from LLM
        full_content = ""
        async for token in self.llm.stream_generate(
            prompt=user_message,
            system_prompt=system_prompt,
            history=history
        ):
            full_content += token
            yield f"event: content\ndata: {json.dumps({'token': token})}\n\n"

        # Yield suggested followups
        yield f"event: followups\ndata: {json.dumps({'items': suggested_followups})}\n\n"

        # Done event
        latency_ms = int((time.time() - start_time) * 1000)
        tokens_count = len(full_content.split())
        yield f"event: done\ndata: {json.dumps({'tokens_used': tokens_count, 'latency_ms': latency_ms})}\n\n"
        
        # Persist conversation message asynchronously
        asyncio.create_task(self.db.conversations.update_one(
            {"_id": conversation_id},
            {"$push": {"messages": {
                "role": "assistant",
                "content": full_content,
                "timestamp": time.time()
            }}}
        ))
