from qdrant_client import QdrantClient
from sentence_transformers import SentenceTransformer
from app.core.config import settings

class RAGService:
    def __init__(self):
        self.client = QdrantClient(url=settings.QDRANT_URL)
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        self.collection_name = "curriculum_docs"

    async def search(self, query: str, subject: str = None, top_k: int = 5):
        """
        Search for relevant curriculum chunks.
        """
        query_vector = self.model.encode(query).tolist()
        
        # Filter by subject if provided
        search_filter = None
        if subject:
            from qdrant_client.http import models
            search_filter = models.Filter(
                must=[models.FieldCondition(key="subject", match=models.MatchValue(value=subject))]
            )

        results = self.client.search(
            collection_name=self.collection_name,
            query_vector=query_vector,
            limit=top_k,
            query_filter=search_filter
        )
        
        return [res.payload["content"] for res in results]

    async def build_context_prompt(self, query: str, subject: str = None) -> str:
        """
        Retrieve chunks and build the context string for the LLM.
        """
        chunks = await self.search(query, subject)
        if not chunks:
            return ""
        
        context_str = "\n".join([f"- {c}" for c in chunks])
        return f"\nRelevant Curriculum Context:\n{context_str}\n"
