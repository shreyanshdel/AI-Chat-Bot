from typing import Annotated, List, Union, Dict
from typing_extensions import TypedDict
from langgraph.graph import StateGraph, END
from app.ml.pipelines.rag_pipeline import RAGPipeline
from app.integrations.openai_client import OpenAIClient
from app.core.config.prompts import SystemPrompts

class AgentState(TypedDict):
    """The state of the multi-agent academic conversation."""
    query: str
    plan: List[str]
    context: str
    reasoning_paths: List[str]
    draft_response: str
    critique: str
    final_response: str
    student_profile: Dict
    steps_completed: int

class MultiAgentOrchestrator:
    """
    Frontier 2026 Multi-Agent Orchestrator.
    Collaborative network of specialized agents: Planner, Researcher, Solver, Teacher, Critic.
    """
    def __init__(self):
        self.llm = OpenAIClient() # MoE Foundation Model (e.g. Mixtral 8x22B)
        self.rag = RAGPipeline()
        
        # Build the LangGraph
        self.workflow = StateGraph(AgentState)
        
        # Define Nodes
        self.workflow.add_node("planner", self._planner_agent)
        self.workflow.add_node("researcher", self._researcher_agent)
        self.workflow.add_node("solver", self._solver_agent)
        self.workflow.add_node("teacher", self._teacher_agent)
        self.workflow.add_node("critic", self._critic_agent)
        
        # Define Edges
        self.workflow.set_entry_point("planner")
        self.workflow.add_edge("planner", "researcher")
        self.workflow.add_edge("researcher", "solver")
        self.workflow.add_edge("solver", "teacher")
        self.workflow.add_edge("teacher", "critic")
        
        # Conditional Edge: Self-Correction loop
        self.workflow.add_conditional_edges(
            "critic",
            self._should_continue,
            {
                "rewrite": "teacher",
                "finish": END
            }
        )
        
        self.app = self.workflow.compile()

    async def _planner_agent(self, state: AgentState):
        """Decomposes the query into sub-tasks and academic objectives."""
        prompt = f"Decompose this student query into an academic plan: {state['query']}"
        plan = await self.llm.generate(prompt)
        return {"plan": [plan], "steps_completed": 1}

    async def _researcher_agent(self, state: AgentState):
        """Retrieves verified facts from the Knowledge Graph and Curriculum DB."""
        context = await self.rag.execute(state['query'])
        return {"context": context}

    async def _solver_agent(self, state: AgentState):
        """Executes symbolic math, code, or simulations to verify logic."""
        # In 2026: Triggers E2B Sandbox or Pyodide
        return {"reasoning_paths": ["Logic verified via sandboxed execution."]}

    async def _teacher_agent(self, state: AgentState):
        """Composes the final response following the 4-layer pedagogical structure."""
        prompt = f"Compose a 4-layer teaching response for: {state['query']} using context: {state['context']}"
        response = await self.llm.generate(prompt, system_prompt=SystemPrompts.STUDYMATE_CORE)
        return {"draft_response": response}

    async def _critic_agent(self, state: AgentState):
        """Reviews the answer for accuracy, tone, and pedagogical depth."""
        critique_prompt = f"Critique this response for Class 10 student accuracy: {state['draft_response']}"
        critique = await self.llm.generate(critique_prompt)
        # Decision logic for rewriting
        is_good = "PASSED" in critique.upper()
        return {"critique": critique, "final_response": state['draft_response'] if is_good else ""}

    def _should_continue(self, state: AgentState):
        if not state.get("final_response"):
            return "rewrite"
        return "finish"

    async def execute(self, query: str, profile: Dict):
        inputs = {"query": query, "student_profile": profile, "steps_completed": 0}
        final_state = await self.app.ainvoke(inputs)
        return final_state["final_response"]
