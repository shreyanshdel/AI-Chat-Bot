from app.core.config.prompts import SystemPrompts

class PromptBuilder:
    """
    Handles the construction of complex pedagogical system prompts.
    """
    @staticmethod
    def build_system_prompt(feature: str = "general") -> str:
        return SystemPrompts.STUDYMATE_CORE

    @staticmethod
    def inject_rag_context(prompt: str, context: str) -> str:
        if not context:
            return prompt
        return f"{prompt}\n\nRELEVANT CONTEXT:\n{context}"
