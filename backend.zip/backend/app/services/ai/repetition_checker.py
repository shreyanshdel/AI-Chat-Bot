from sentence_transformers import util
import torch

class RepetitionChecker:
    """
    Highly specific service for detecting textual overlap in AI responses.
    """
    def __init__(self, model):
        self.model = model

    def calculate_similarity(self, text1: str, text2: str) -> float:
        embeddings = self.model.encode([text1, text2], convert_to_tensor=True)
        return util.cos_sim(embeddings[0], embeddings[1]).item()

    def is_repeated(self, draft: str, history: list, threshold: float = 0.85) -> bool:
        last_msgs = [m["content"] for m in history if m["role"] == "assistant"][-3:]
        for msg in last_msgs:
            if self.calculate_similarity(draft, msg) > threshold:
                return True
        return False
