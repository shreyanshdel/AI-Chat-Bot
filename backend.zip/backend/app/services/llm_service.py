import os
import json
import httpx
import logging
import asyncio
from app.core.config.settings import settings

logger = logging.getLogger("services.llm")

class LLMService:
    def __init__(self):
        self.api_key = settings.OPENAI_API_KEY or os.environ.get("OPENAI_API_KEY", "")
        self.gemini_key = settings.GEMINI_API_KEY or os.environ.get("GEMINI_API_KEY", "")
        self.anthropic_key = settings.ANTHROPIC_API_KEY or os.environ.get("ANTHROPIC_API_KEY", "")

    async def generate(self, prompt: str, system_prompt: str, history: list, temperature: float = 0.8, presence_penalty: float = 0.6, frequency_penalty: float = 0.3) -> str:
        """
        Non-streaming generate fallback for repetition checks.
        """
        logger.info(f"Generating LLM response for: {prompt[:30]}...")
        
        # Build prompt messages
        messages = [{"role": "system", "content": system_prompt}]
        for msg in history:
            messages.append({
                "role": msg.get("role", "user"),
                "content": msg.get("content", "")
            })
        messages.append({"role": "user", "content": prompt})

        # OpenAI API Call
        if self.api_key:
            try:
                async with httpx.AsyncClient(timeout=30.0) as client:
                    response = await client.post(
                        "https://api.openai.com/v1/chat/completions",
                        headers={
                            "Authorization": f"Bearer {self.api_key}",
                            "Content-Type": "application/json"
                        },
                        json={
                            "model": "gpt-4o-mini",
                            "messages": messages,
                            "temperature": temperature,
                            "presence_penalty": presence_penalty,
                            "frequency_penalty": frequency_penalty,
                            "max_tokens": 1000
                        }
                    )
                    if response.status_code == 200:
                        data = response.json()
                        return data["choices"][0]["message"]["content"]
            except Exception as e:
                logger.error(f"OpenAI generate error: {e}")

        # Fallback to simulated response
        q = prompt.lower()
        if "photo" in q or "plant" in q or "leaf" in q or "biology" in q:
            return (
                "Imagine the plant on your balcony is a chef. Every single day, using only three ingredients — sunlight, water, and the air you exhale — it cooks its own food. No stove, no Swiggy. That kitchen magic is **Photosynthesis**.\n\n"
                "### The Simple Recipe\n"
                "6 CO₂ + 6 H₂O + sunlight → C₆H₁₂O₆ + 6 O₂\n\n"
                "### Where it Happens\n"
                "Inside microscopic green solar panels called **chloroplasts** [the food factories of plant cells] which contain a green pigment called **chlorophyll** to trap solar energy.\n\n"
                "Avoid thinking that plants only do this in the daytime! While the light-dependent reactions need sun, the dark reaction (Calvin Cycle) can keep cooking without direct sunlight! Do you want to know how they store this glucose?"
            )
        elif "gravit" in q or "newton" in q or "physics" in q or "force" in q:
            return (
                "Imagine you're checking your phone in bed and it slips, hitting you right in the face. Why does it always fall down, never up? That invisible cosmic magnet is **Gravity** [the attractive force between any two objects with mass].\n\n"
                "### The Big Idea, Simply\n"
                "Every single thing in the universe pulls on every other thing. You pull on the Earth, and the Earth pulls on you! But because Earth is so enormous, its pull is the only one you really feel.\n\n"
                "### The Formula\n"
                "F = G * (m₁ * m₂) / r²\n"
                "Where F is force, G is the gravitational constant (6.674e-11), m₁ & m₂ are masses, and r is the distance between their centers.\n\n"
                "Remember: Gravity never turns off! Even astronauts in orbit are actually in constant freefall around the Earth, not floating in zero gravity! Can you guess why satellites don't crash into us?"
            )
        else:
            return (
                f"Let's dive into **{prompt}**! To make this super clear, let's look at the big picture first.\n\n"
                f"### The Hook\n"
                f"Think of this like when you're playing a multiplayer game and you need a strategy to win. Understanding this concept is your strategy for mastering this topic!\n\n"
                f"### The Simple Explanation\n"
                f"Basically, this is just a system designed to solve a specific problem by coordinating different parts together so everything runs smoothly.\n\n"
                f"### The Detailed Breakdown\n"
                f"1. **Core Mechanism**: It operates by taking inputs, processing them, and returning outputs.\n"
                f"2. **Key Terms**: Define every term clearly in bracket annotations.\n"
                f"3. **Worked Example**: If we have a simple scenario, we compute it step-by-step.\n\n"
                f"Mnemonic to remember: *Keep It Super Simple!* What particular part of this concept would you like to explore deeper?"
            )

    async def stream_generate(self, prompt: str, system_prompt: str, history: list, temperature: float = 0.8, presence_penalty: float = 0.6, frequency_penalty: float = 0.3):
        """
        Streaming async generator of tokens.
        """
        messages = [{"role": "system", "content": system_prompt}]
        for msg in history:
            messages.append({
                "role": msg.get("role", "user"),
                "content": msg.get("content", "")
            })
        messages.append({"role": "user", "content": prompt})

        # OpenAI API Call with Stream
        if self.api_key:
            try:
                async with httpx.AsyncClient(timeout=30.0) as client:
                    async with client.stream(
                        "POST",
                        "https://api.openai.com/v1/chat/completions",
                        headers={
                            "Authorization": f"Bearer {self.api_key}",
                            "Content-Type": "application/json"
                        },
                        json={
                            "model": "gpt-4o-mini",
                            "messages": messages,
                            "temperature": temperature,
                            "presence_penalty": presence_penalty,
                            "frequency_penalty": frequency_penalty,
                            "stream": True
                        }
                    ) as response:
                        if response.status_code == 200:
                            async for chunk in response.aiter_lines():
                                if chunk.startswith("data: "):
                                    data_str = chunk[6:].strip()
                                    if data_str == "[DONE]":
                                        break
                                    try:
                                        data = json.loads(data_str)
                                        token = data["choices"][0]["delta"].get("content", "")
                                        if token:
                                            yield token
                                    except Exception:
                                        continue
                            return
            except Exception as e:
                logger.error(f"OpenAI stream error: {e}")

        # Fallback to simulated response streamed word-by-word
        q = prompt.lower()
        if "photo" in q or "plant" in q or "leaf" in q or "biology" in q:
            response_text = (
                "Imagine the plant on your balcony is a chef. Every single day, using only three ingredients — sunlight, water, and the air you exhale — it cooks its own food. No stove, no Swiggy. That kitchen magic is **Photosynthesis**.\n\n"
                "### The Simple Recipe\n"
                "6 CO₂ + 6 H₂O + sunlight → C₆H₁₂O₆ + 6 O₂\n\n"
                "### Where it Happens\n"
                "Inside microscopic green solar panels called **chloroplasts** [the food factories of plant cells] which contain a green pigment called **chlorophyll** to trap solar energy.\n\n"
                "Avoid thinking that plants only do this in the daytime! While the light-dependent reactions need sun, the dark reaction (Calvin Cycle) can keep cooking without direct sunlight! Do you want to know how they store this glucose?"
            )
        elif "gravit" in q or "newton" in q or "physics" in q or "force" in q:
            response_text = (
                "Imagine you're checking your phone in bed and it slips, hitting you right in the face. Why does it always fall down, never up? That invisible cosmic magnet is **Gravity** [the attractive force between any two objects with mass].\n\n"
                "### The Big Idea, Simply\n"
                "Every single thing in the universe pulls on every other thing. You pull on the Earth, and the Earth pulls on you! But because Earth is so enormous, its pull is the only one you really feel.\n\n"
                "### The Formula\n"
                "F = G * (m₁ * m₂) / r²\n"
                "Where F is force, G is the gravitational constant (6.674e-11), m₁ & m₂ are masses, and r is the distance between their centers.\n\n"
                "Remember: Gravity never turns off! Even astronauts in orbit are actually in constant freefall around the Earth, not floating in zero gravity! Can you guess why satellites don't crash into us?"
            )
        else:
            response_text = (
                f"Let's dive into **{prompt}**! To make this super clear, let's look at the big picture first.\n\n"
                f"### The Hook\n"
                f"Think of this like when you're playing a multiplayer game and you need a strategy to win. Understanding this concept is your strategy for mastering this topic!\n\n"
                f"### The Simple Explanation\n"
                f"Basically, this is just a system designed to solve a specific problem by coordinating different parts together so everything runs smoothly.\n\n"
                f"### The Detailed Breakdown\n"
                f"1. **Core Mechanism**: It operates by taking inputs, processing them, and returning outputs.\n"
                f"2. **Key Terms**: Define every term clearly in bracket annotations.\n"
                f"3. **Worked Example**: If we have a simple scenario, we compute it step-by-step.\n\n"
                f"Mnemonic to remember: *Keep It Super Simple!* What particular part of this concept would you like to explore deeper?"
            )

        for word in response_text.split(" "):
            yield word + " "
            await asyncio.sleep(0.04)
