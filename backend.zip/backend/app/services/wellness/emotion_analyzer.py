from transformers import pipeline
import torch

class EmotionAnalyzer:
    """
    Deep Learning layer for Student Wellness monitoring.
    Uses fine-tuned RoBERTa for high-precision emotion classification.
    """
    def __init__(self):
        # Specific model for psychological/emotional mapping
        self.classifier = pipeline(
            "text-classification",
            model="j-hartmann/emotion-english-distilroberta-base",
            return_all_scores=True
        )

    async def analyze_state(self, message: str) -> dict:
        """
        Detects: Joy, Sadness, Anger, Fear, Surprise, Disgust, Neutral.
        Flags potential burnout if fear/sadness spikes across sessions.
        """
        results = self.classifier(message)[0]
        
        # Sort by score
        sorted_emotions = sorted(results, key=lambda x: x['score'], reverse=True)
        top_emotion = sorted_emotions[0]
        
        return {
            "top_emotion": top_emotion['label'],
            "confidence": top_emotion['score'],
            "full_spectrum": {e['label']: e['score'] for e in results}
        }

    def detect_burnout_risk(self, historical_emotions: list) -> bool:
        """
        Anomaly detection (simplified) on rolling emotion window.
        """
        # In production: Use an LSTM or Autoencoder here.
        negative_count = sum(1 for e in historical_emotions if e in ['fear', 'sadness', 'anger'])
        return negative_count > 5 # Flag if 5+ consecutive negative signals
