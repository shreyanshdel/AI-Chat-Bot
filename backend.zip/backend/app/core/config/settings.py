from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    APP_NAME: str = "StudyMate AI"
    DATABASE_URL: str = "postgresql://user:pass@localhost/db"
    MONGO_URL: str = "mongodb://localhost:27017"
    REDIS_URL: str = "redis://localhost:6379"
    QDRANT_URL: str = "http://localhost:6333"
    OPENAI_API_KEY: str = ""
    GEMINI_API_KEY: str = ""
    ANTHROPIC_API_KEY: str = ""
    SENTRY_DSN: str = ""
    
    class Config:
        env_file = ".env"

settings = Settings()
