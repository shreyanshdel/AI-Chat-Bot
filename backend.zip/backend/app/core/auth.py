from fastapi import Header, HTTPException

class DummyUser:
    def __init__(self, id="jane_doe", name="Jane Doe"):
        self.id = id
        self.name = name

async def get_current_user(authorization: str = Header(default="Bearer dummy_token")) -> DummyUser:
    # Accept any token for the demo/development
    return DummyUser()
