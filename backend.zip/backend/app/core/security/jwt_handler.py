from datetime import datetime, timedelta
from jose import jwt
from app.core.config.settings import settings

class JWTHandler:
    """
    Highly granular utility for token lifecycle management.
    """
    @staticmethod
    def create_access_token(data: dict, expires_delta: timedelta = None):
        to_encode = data.copy()
        expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15))
        to_encode.update({"exp": expire})
        return jwt.encode(to_encode, "SECRET_KEY", algorithm="HS256")

    @staticmethod
    def decode_token(token: str):
        return jwt.decode(token, "SECRET_KEY", algorithms=["HS256"])
