import logging
import asyncio
from motor.motor_asyncio import AsyncIOMotorClient

logger = logging.getLogger("db.mongodb")

client = None
db_instance = None

class MockCursor:
    def __init__(self, data):
        self.data = data

    def sort(self, key, direction=-1):
        # Simply return self, mock sorting is not critical
        return self

    def limit(self, limit_val):
        self.data = self.data[:limit_val]
        return self

    async def to_list(self, length=20):
        await asyncio.sleep(0.01)
        return self.data

class MockConversations:
    def __init__(self):
        self.storage = {}

    async def find_one(self, filter_query):
        await asyncio.sleep(0.01)
        conv_id = filter_query.get("_id")
        return self.storage.get(conv_id)

    def find(self, filter_query):
        conv_id = filter_query.get("_id")
        conv = self.storage.get(conv_id)
        messages = conv.get("messages", []) if conv else []
        return MockCursor(messages)

    async def update_one(self, filter_query, update_query, upsert=True):
        await asyncio.sleep(0.01)
        conv_id = filter_query.get("_id")
        if conv_id not in self.storage:
            self.storage[conv_id] = {
                "_id": conv_id,
                "messages": [],
                "user_id": "jane_doe",
                "updated_at": asyncio.get_event_loop().time()
            }
        
        conv = self.storage[conv_id]
        if "$push" in update_query:
            push_data = update_query["$push"]
            if "messages" in push_data:
                conv["messages"].append(push_data["messages"])
        
        conv["updated_at"] = asyncio.get_event_loop().time()
        return True

class MockMongoDB:
    def __init__(self):
        self.conversations = MockConversations()

async def init_mongo():
    global client, db_instance
    from app.core.config.settings import settings
    try:
        client = AsyncIOMotorClient(settings.MONGO_URL, serverSelectionTimeoutMS=2000)
        db_instance = client.get_default_database()
        # Test connection
        await client.server_info()
        logger.info("MongoDB connected successfully")
    except Exception as e:
        logger.warning(f"MongoDB connection failed: {e}. Falling back to in-memory Mock MongoDB.")
        db_instance = MockMongoDB()

def get_mongo_db():
    if db_instance is None:
        raise Exception("MongoDB not initialized")
    return db_instance
