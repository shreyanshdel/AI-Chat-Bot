import logging
import redis

logger = logging.getLogger("db.redis")

redis_client = None

class MockRedis:
    def __init__(self):
        self.storage = {}

    def get(self, key):
        return self.storage.get(key)

    def set(self, key, value, ex=None):
        self.storage[key] = value
        return True

    def ping(self):
        return True

async def init_redis():
    global redis_client
    from app.core.config.settings import settings
    try:
        redis_client = redis.from_url(settings.REDIS_URL, socket_connect_timeout=2)
        redis_client.ping()
        logger.info("Redis connected successfully")
    except Exception as e:
        logger.warning(f"Redis connection failed: {e}. Falling back to in-memory Mock Redis.")
        redis_client = MockRedis()

def get_redis():
    if redis_client is None:
        raise Exception("Redis not initialized")
    return redis_client
