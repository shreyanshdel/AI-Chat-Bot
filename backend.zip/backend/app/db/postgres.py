import logging
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.core.config.settings import settings

logger = logging.getLogger("db.postgres")

engine = None
SessionLocal = None

async def init_postgres():
    global engine, SessionLocal
    try:
        engine = create_engine(settings.DATABASE_URL, connect_args={"connect_timeout": 2})
        SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
        # Test connection
        with engine.connect() as conn:
            pass
        logger.info("PostgreSQL connected successfully")
    except Exception as e:
        logger.warning(f"PostgreSQL connection failed: {e}. Falling back to SQLite/In-memory mock.")
        # Fallback to SQLite in-memory
        engine = create_engine("sqlite:///:memory:")
        SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db():
    if SessionLocal is None:
        raise Exception("Database not initialized")
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
