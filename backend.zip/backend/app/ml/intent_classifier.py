import logging

logger = logging.getLogger("ml.intent_classifier")

class IntentClassifier:
    def __init__(self):
        pass

    def predict(self, text: str) -> str:
        q = text.lower()
        if "photo" in q or "plant" in q or "leaf" in q or "biology" in q or "cell" in q:
            return "Biology"
        elif "gravit" in q or "newton" in q or "physics" in q or "force" in q:
            return "Physics"
        elif "math" in q or "solve" in q or "equation" in q or "x" in q:
            return "Math"
        else:
            return "General Science"
