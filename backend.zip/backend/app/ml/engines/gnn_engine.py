import torch
import torch.nn.functional as F
from torch_geometric.nn import GATConv
from torch_geometric.data import Data

class KnowledgeGAT(torch.nn.Module):
    """
    Graph Attention Network (GAT) for diagnostic tutoring.
    Assigns attention scores to prerequisites to find the 'root cause' of failure.
    """
    def __init__(self, in_channels: int, out_channels: int, heads: int = 4):
        super(KnowledgeGAT, self).__init__()
        self.conv1 = GATConv(in_channels, 16, heads=heads, dropout=0.1)
        self.conv2 = GATConv(16 * heads, out_channels, heads=1, concat=False, dropout=0.1)

    def forward(self, x, edge_index):
        x = F.dropout(x, p=0.1, training=self.training)
        x = self.conv1(x, edge_index).relu()
        x = F.dropout(x, p=0.1, training=self.training)
        x = self.conv2(x, edge_index)
        return torch.sigmoid(x)

class KnowledgeTracingEngine:
    """
    Tracks the student's mastery through the 50,000-node Curriculum Graph.
    Uses Graph Attention to predict which prerequisite is blocking the student.
    """
    def __init__(self):
        self.model = KnowledgeGAT(in_channels=128, out_channels=1) # 128 = Embedding size
        
    def trace_bottleneck(self, node_id: int, mastery_snapshot: torch.Tensor, edge_index: torch.Tensor):
        """
        Back-traverse the graph using attention weights to find the 'Doubt Source'.
        """
        self.model.eval()
        with torch.no_grad():
            preds = self.model(mastery_snapshot, edge_index)
            
        # Analyze attention weights (requires returning weights from GATConv)
        # Simplified: return the prerequisite with the lowest mastery score and highest dependency
        return "Prerequisite: Fundamental Laws of Algebra (Class 8)"
