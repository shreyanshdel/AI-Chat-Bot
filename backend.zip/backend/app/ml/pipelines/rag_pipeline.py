from app.integrations.openai_client import OpenAIClient
from app.integrations.vector_db.qdrant import QdrantClient

class RAGPipeline:
    """
    Modular pipeline for Retrieval Augmented Generation.
    """
    def __init__(self):
        self.vector_db = QdrantClient()
        self.llm = OpenAIClient()

    async def execute(self, query: str, top_k: int = 5):
        # 1. Retrieve
        context = await self.vector_db.search(query, limit=top_k)
        
        # 2. Augment & Generate
        return await self.llm.generate_with_context(query, context)
