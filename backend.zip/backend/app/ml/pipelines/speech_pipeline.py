import whisper
import torch
from TTS.api import TTS # Coqui TTS
from app.core.config.settings import settings

class SpeechPipeline:
    """
    Multilingual Speech Deep Learning Pipeline.
    Powers Transcription (Whisper) and Voice Output (XTTS-v2).
    """
    def __init__(self):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        
        # 1. ASR (Automatic Speech Recognition)
        self.asr_model = whisper.load_model("large-v3", device=self.device)
        
        # 2. TTS (Text-to-Speech)
        # Supports 16+ languages including Hindi, Tamil, Bengali
        self.tts = TTS("tts_models/multilingual/multi-dataset/xtts_v2").to(self.device)

    async def transcribe(self, audio_path: str) -> str:
        """Transcribe student doubt in any Indian language."""
        result = self.asr_model.transcribe(audio_path)
        return result["text"]

    async def speak(self, text: str, output_path: str, language: str = "hi"):
        """Generate natural tutor voice in the student's language."""
        self.tts.tts_to_file(
            text=text,
            file_path=output_path,
            speaker_wav="app/assets/voices/tutor_sample.wav", # Clone voice
            language=language
        )
