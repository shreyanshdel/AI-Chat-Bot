import torch
from PIL import Image
from transformers import AutoProcessor, LlavaForConditionalGeneration
from app.core.config.settings import settings

class VLMPipeline:
    """
    Multimodal Deep Learning pipeline for Vision-Language tasks.
    Powers 'Snap & Solve' and Diagram Understanding.
    """
    def __init__(self):
        self.model_id = "llava-hf/llava-1.5-7b-hf" # Placeholder for production checkpoint
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        
        # Load processor and model
        # Note: In production, this would be served via Triton or vLLM
        self.processor = AutoProcessor.from_pretrained(self.model_id)
        self.model = LlavaForConditionalGeneration.from_pretrained(
            self.model_id, 
            torch_dtype=torch.float16, 
            low_cpu_mem_usage=True
        ).to(self.device)

    async def solve_image(self, image_path: str, user_query: str) -> str:
        """
        Reason about a student's photo (handwritten math, biology diagram, etc.)
        """
        image = Image.open(image_path)
        
        # Prompt following StudyMate CoT logic
        prompt = f"USER: <image>\n{user_query}\nASSISTANT: Let's think step-by-step."
        
        inputs = self.processor(text=prompt, images=image, return_tensors="pt").to(self.device, torch.float16)
        
        output = self.model.generate(**inputs, max_new_tokens=500)
        decoded = self.processor.decode(output[0], skip_special_tokens=True)
        
        return decoded.split("ASSISTANT:")[-1].strip()
