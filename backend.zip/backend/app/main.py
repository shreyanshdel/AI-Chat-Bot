from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
try:
    import sentry_sdk
except ImportError:
    sentry_sdk = None

try:
    from prometheus_fastapi_instrumentator import Instrumentator
except ImportError:
    Instrumentator = None

from app.core.config.settings import settings
from app.api import auth, chat, features, admin
from app.db.mongodb import init_mongo
from app.db.postgres import init_postgres
from app.db.redis import init_redis

# Initialize Sentry
if sentry_sdk and settings.SENTRY_DSN:
    sentry_sdk.init(dsn=settings.SENTRY_DSN, traces_sample_rate=1.0)

app = FastAPI(
    title="StudyMate AI API",
    description="Production-grade backend for the ML-powered student chatbot.",
    version="1.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # In production, replace with specific domains
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Startup & Shutdown Events
@app.on_event("startup")
async def startup_event():
    await init_mongo()
    await init_postgres()
    await init_redis()
    print("StudyMate AI Backend Started")

@app.on_event("shutdown")
async def shutdown_event():
    # Cleanup logic
    pass

# Include Routers
app.include_router(auth.router, prefix="/auth", tags=["Authentication"])
app.include_router(chat.router, prefix="/chat", tags=["Chat Engine"])
app.include_router(features.router, prefix="/features", tags=["ML Features"])
app.include_router(admin.router, prefix="/admin", tags=["Admin & Analytics"])

# Health Check
@app.get("/health")
async def health_check():
    return {"status": "healthy", "version": "1.0.0"}

# Prometheus Monitoring
if Instrumentator:
    Instrumentator().instrument(app).expose(app)
