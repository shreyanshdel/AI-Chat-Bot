from fastapi import APIRouter, Depends, Body, Header
from fastapi.responses import StreamingResponse
from app.services.chat_engine import ChatEngine
from app.db.mongodb import get_mongo_db
from app.core.auth import get_current_user
from app.models.chat import ChatMessageRequest
import json
import asyncio

router = APIRouter()

@router.post("/message")
async def send_message(
    request: ChatMessageRequest = Body(...),
    user = Depends(get_current_user),
    db = Depends(get_mongo_db)
):
    """
    Send a message and receive a streaming AI reply via SSE.
    """
    engine = ChatEngine(db)
    
    async def event_generator():
        # First, log user message to DB
        asyncio.create_task(db.conversations.update_one(
            {"_id": request.conversation_id},
            {"$push": {"messages": {
                "role": "user",
                "content": request.message,
                "timestamp": asyncio.get_event_loop().time()
            }}}
        ))

        async for event in engine.stream_response(
            conversation_id=request.conversation_id,
            user_message=request.message,
            feature_hint=request.feature_hint
        ):
            yield event

    return StreamingResponse(event_generator(), media_type="text/event-stream")

@router.get("/conversations")
async def list_conversations(user = Depends(get_current_user), db = Depends(get_mongo_db)):
    cursor = db.conversations.find({"user_id": user.id}).sort("updated_at", -1)
    return await cursor.to_list(length=50)

@router.get("/conversations/{id}")
async def get_conversation(id: str, user = Depends(get_current_user), db = Depends(get_mongo_db)):
    conv = await db.conversations.find_one({"_id": id, "user_id": user.id})
    if not conv:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return conv
