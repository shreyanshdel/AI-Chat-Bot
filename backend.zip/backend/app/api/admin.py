from fastapi import APIRouter

router = APIRouter()

@router.get("/stats")
async def get_stats():
    return {"users": 1, "queries": 10}
