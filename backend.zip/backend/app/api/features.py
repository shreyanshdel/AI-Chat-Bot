from fastapi import APIRouter

router = APIRouter()

@router.get("/list")
async def list_features():
    return {"features": ["ocr", "tts", "plagiarism"]}
