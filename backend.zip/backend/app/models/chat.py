from pydantic import BaseModel
from typing import Optional

class ChatMessageRequest(BaseModel):
    conversation_id: str
    message: str
    feature_hint: Optional[str] = None
