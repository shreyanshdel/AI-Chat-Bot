# StudyMate AI Backend

Production-ready, scalable backend for the ML-powered student chatbot.

## 🏗️ Architecture
- **API**: FastAPI (Asynchronous, Type-safe)
- **Primary DB**: PostgreSQL (Users, Study Plans)
- **NoSQL**: MongoDB (Chat History, Flashcards)
- **Cache/Queue**: Redis (Rate limiting, Celery broker)
- **Vector DB**: Qdrant (RAG, Curriculum embeddings)
- **ML Inference**: Hugging Face + ONNX Runtime

## 🚀 Key Features
- **Streaming Chat Engine**: Real-time token streaming via SSE.
- **Variety Enforcement**: Cosine similarity check (S-BERT) to prevent repetitive AI responses.
- **RAG Pipeline**: Curriculum-aware context injection using vector search.
- **Spaced Repetition**: FSRS-4 algorithm for long-term memory coaching.
- **Adaptive Learning**: IRT-based quiz difficulty tuning (logic in `services/quiz.py`).
- **Async Workers**: Celery for heavy tasks (PDF parsing, transcription).

## 🛠️ Setup (Local)
1. Ensure Docker & Docker Compose are installed.
2. Create a `.env` file from the template.
3. Run `docker-compose up --build`.
4. Access API docs at `http://localhost:8000/docs`.

## 🧪 Success Criteria
- **Latency**: < 500ms TTFT (Time To First Token) for chat.
- **Scalability**: Designed for 100K+ users with K8s autoscaling.
- **Uniqueness**: Similarity score < 0.85 between consecutive assistant responses.
- **Security**: JWT rotate, PII sanitization, and Pydantic validation.

## 📁 Directory Structure
```text
backend/
├── app/
│   ├── api/        # REST & WebSocket Routers
│   ├── core/       # Security, Auth, Config
│   ├── services/   # Business & ML Logic (Chat, RAG, FSRS)
│   ├── models/     # Pydantic & SQLAlchemy Models
│   ├── ml/         # Intent Classification & Inference
│   ├── tasks/      # Celery Async Jobs
│   └── db/         # DB Connections (Mongo, Postgres, Redis)
├── alembic/        # DB Migrations
└── tests/          # Pytest Suite
```
