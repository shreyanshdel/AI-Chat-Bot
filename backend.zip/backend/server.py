"""
StudyMate AI — Minimal LLM Proxy Server
========================================

A single-file FastAPI server that connects the StudyMate AI frontend
(`Chatbot/app.html`) to a real LLM. Zero database dependencies —
runs anywhere with just Python + an OpenAI API key.

Boot it with:

    cd Chatbot/backend
    pip install -r requirements-min.txt        # see file in same dir
    OPENAI_API_KEY=sk-... python server.py     # or use a .env file

Frontend points at http://localhost:8000/chat/message by default.

Endpoints:
  POST /chat/message   -> Server-Sent Events stream
  GET  /health         -> liveness probe
"""

import os
import json
import asyncio
import logging
from typing import AsyncGenerator, Optional

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
load_dotenv()  # picks up Chatbot/backend/.env if present

OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "").strip()
OPENAI_BASE = "https://api.openai.com/v1/chat/completions"

# Mode -> model + sampling preset. Frontend sends one of these via `feature_hint`.
MODE_PRESETS = {
    "quick":  {"model": "gpt-4o-mini",  "temperature": 0.4, "max_tokens": 600},
    "deep":   {"model": "gpt-4o-mini",  "temperature": 0.8, "max_tokens": 1200},
    "search": {"model": "gpt-4o-mini",  "temperature": 0.7, "max_tokens": 1500},
}

SYSTEM_PROMPT = """You are StudyMate, a warm, witty, exam-savvy AI tutor for students aged 13-22.
You teach for the Indian CBSE / ICSE / state boards and major entrance exams (JEE, NEET, UPSC, GATE).

Style rules (follow strictly):
- Open every answer with a short, vivid real-world hook (1-2 sentences).
- Then a Markdown **## heading** for the core idea, followed by a clean explanation.
- Use **bold** for key terms. Use [square brackets] for short definitions inline.
- When math appears, show the formula on its own line in plain text (e.g. `F = G * m1 * m2 / r^2`).
- Use `### Sub-headings` for sub-sections. Use bullet lists where 3+ items are equally weighted.
- End with one short Examiner Tip OR an encouraging follow-up question.
- Keep it under 250 words unless the student explicitly asks for more.
- Never say "as an AI"; speak like a friendly senior who knows the syllabus cold.
- If the student is stressed or emotional, drop the lecture style and respond with empathy first.
"""

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("studymate")

# ---------------------------------------------------------------------------
# Subject routing — picks a colored "expert badge" for the frontend
# ---------------------------------------------------------------------------
SUBJECT_TABLE = [
    # (keywords, subject, expertName, badgeColor, pulseColor, thinking)
    (
        ("photo", "plant", "leaf", "chloroplast", "biology", "cell", "dna",
         "respiration", "ecosystem"),
        "Biology", "Biology Expert",
        "bg-green-50 text-forest border-green-200", "bg-green-500",
        ["Identifying topic: Biology",
         "Querying NCERT curriculum graph",
         "Routing to the Biology specialist",
         "Streaming answer with safety + style guards"]
    ),
    (
        ("gravit", "newton", "physics", "force", "velocity", "acceleration",
         "motion", "energy", "current", "circuit", "magnet", "wave"),
        "Physics", "Physics Expert",
        "bg-orange-50 text-[#C2410C] border-orange-200", "bg-orange-600",
        ["Identifying topic: Physics",
         "Looking up Universal-Law / kinematics references",
         "Routing to the Physics specialist",
         "Streaming step-by-step explanation"]
    ),
    (
        ("math", "equation", "solve", "quadratic", "algebra", "geometry",
         "trigonometry", "probability", "integral", "derivative", "calculus"),
        "Math", "Math Expert",
        "bg-purple-50 text-purple-800 border-purple-200", "bg-purple-500",
        ["Parsing the symbolic problem",
         "Applying algebraic balance rules",
         "Verifying each step",
         "Streaming the worked solution"]
    ),
    (
        ("chemistry", "reaction", "molecule", "atom", "bond", "acid", "base",
         "salt", "valence", "oxidation"),
        "Chemistry", "Chemistry Expert",
        "bg-cyan-50 text-cyan-800 border-cyan-200", "bg-cyan-500",
        ["Identifying topic: Chemistry",
         "Looking up reactant / product set",
         "Routing to the Chemistry specialist",
         "Streaming the balanced explanation"]
    ),
    (
        ("stress", "anxious", "anxiety", "scared", "overwhelm", "tired",
         "sad", "exam fear"),
        "Wellbeing", "Wellbeing Buddy",
        "bg-pink-50 text-pink-700 border-pink-200", "bg-pink-500",
        ["Reading the emotional tone",
         "Switching to supportive style",
         "Selecting a grounding technique",
         "Composing a kind reply"]
    ),
]

DEFAULT_EXPERT = (
    "General Science", "General Science Specialist",
    "bg-blue-50 text-blue-800 border-blue-200", "bg-blue-500",
    ["Identifying semantic intent",
     "Querying active curriculum database",
     "Routing to the general specialist",
     "Streaming a custom explanation"]
)


def classify(message: str):
    q = message.lower()
    for keywords, subject, name, badge, pulse, steps in SUBJECT_TABLE:
        if any(k in q for k in keywords):
            return subject, name, badge, pulse, steps
    return DEFAULT_EXPERT


def followups_for(subject: str):
    return {
        "Biology": [
            "Solve a board-style question on this",
            "What happens to plants at night?",
            "Connect this to cellular respiration",
        ],
        "Physics": [
            "Why doesn't the moon fall into the earth?",
            "What is the difference between mass and weight?",
            "Solve a numerical on gravity calculation",
        ],
        "Math": [
            "Walk me through another example",
            "Give me a tricky variation of this",
            "Where does this appear in the boards?",
        ],
        "Chemistry": [
            "Balance a related reaction",
            "Show this with real-life examples",
            "How is this tested in the boards?",
        ],
        "Wellbeing": [
            "Suggest a 2-minute breathing exercise",
            "Help me make a small study plan for today",
            "Tell me a confidence-boosting story",
        ],
    }.get(subject, [
        "Explain this in more detail",
        "Give me a quick quiz on this",
        "How does this connect to my board exam?",
    ])


# ---------------------------------------------------------------------------
# FastAPI app
# ---------------------------------------------------------------------------
app = FastAPI(title="StudyMate AI — Minimal LLM Proxy", version="0.1.0")

# CORS — open during local development. Lock down before any real deployment.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class ChatRequest(BaseModel):
    conversation_id: Optional[str] = Field(default="default")
    message: str
    feature_hint: Optional[str] = Field(default="deep")  # quick | deep | search


def sse(event: str, data: dict) -> bytes:
    """Format a Server-Sent Events frame the way the frontend parser expects."""
    return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n".encode("utf-8")


# ---------------------------------------------------------------------------
# Token streamer — real OpenAI if key is set, otherwise a clear fallback.
# ---------------------------------------------------------------------------
FALLBACK_BIO = (
    "Imagine the plant on your balcony is a chef. Every single day, using only three "
    "ingredients — sunlight, water, and the air you exhale — it cooks its own food. "
    "No stove, no Swiggy. That kitchen magic is **Photosynthesis**.\n\n"
    "### The Simple Recipe\n"
    "6 CO₂ + 6 H₂O + sunlight → C₆H₁₂O₆ + 6 O₂\n\n"
    "### Where it Happens\n"
    "Inside microscopic green solar panels called **chloroplasts** [the food factories "
    "of plant cells] which contain a green pigment called **chlorophyll** to trap solar "
    "energy.\n\n"
    "Avoid thinking that plants only do this in the daytime! While the light-dependent "
    "reactions need sun, the dark reaction (Calvin Cycle) can keep cooking without "
    "direct sunlight! Do you want to know how they store this glucose?"
)

FALLBACK_PHY = (
    "Imagine you're checking your phone in bed and it slips, hitting you right in the face. "
    "Why does it always fall down, never up? That invisible cosmic magnet is **Gravity** "
    "[the attractive force between any two objects with mass].\n\n"
    "### The Big Idea, Simply\n"
    "Every single thing in the universe pulls on every other thing. You pull on the Earth, "
    "and the Earth pulls on you! But because Earth is so enormous, its pull is the only one "
    "you really feel.\n\n"
    "### The Formula\n"
    "F = G * (m₁ * m₂) / r²\n"
    "Where F is force, G is the gravitational constant (6.674e-11), m₁ & m₂ are masses, "
    "and r is the distance between their centers.\n\n"
    "Remember: Gravity never turns off! Even astronauts in orbit are in constant freefall "
    "around the Earth. Can you guess why satellites don't crash into us?"
)


def fallback_text(message: str) -> str:
    q = message.lower()
    if any(k in q for k in ("photo", "plant", "leaf", "biology", "chloroplast")):
        return FALLBACK_BIO
    if any(k in q for k in ("gravit", "newton", "physics", "force")):
        return FALLBACK_PHY
    return (
        f"Set your `OPENAI_API_KEY` in `Chatbot/backend/.env` to get real answers.\n\n"
        f"### Demo Fallback\n"
        f"You asked: **{message}**.\n\n"
        f"Once a key is set, this same endpoint will stream a real explanation in "
        f"StudyMate's friendly tutor voice, tailored to the Indian board syllabus, "
        f"with worked steps, formula boxes and follow-up questions."
    )


async def stream_tokens(message: str, mode: str) -> AsyncGenerator[str, None]:
    """Yields content tokens one at a time."""
    preset = MODE_PRESETS.get(mode, MODE_PRESETS["deep"])

    if not OPENAI_API_KEY:
        log.warning("OPENAI_API_KEY is not set — streaming local fallback.")
        text = fallback_text(message)
        for word in text.split(" "):
            yield word + " "
            await asyncio.sleep(0.025)
        return

    headers = {
        "Authorization": f"Bearer {OPENAI_API_KEY}",
        "Content-Type": "application/json",
    }
    body = {
        "model": preset["model"],
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": message},
        ],
        "temperature": preset["temperature"],
        "max_tokens": preset["max_tokens"],
        "stream": True,
    }

    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            async with client.stream("POST", OPENAI_BASE, headers=headers, json=body) as resp:
                if resp.status_code != 200:
                    err_body = await resp.aread()
                    log.error("OpenAI %s: %s", resp.status_code, err_body.decode("utf-8", "replace"))
                    yield (
                        f"\n\n_OpenAI returned HTTP {resp.status_code}. "
                        f"Check that your `OPENAI_API_KEY` is valid and has credit._\n"
                    )
                    return
                async for line in resp.aiter_lines():
                    if not line or not line.startswith("data: "):
                        continue
                    payload = line[6:].strip()
                    if payload == "[DONE]":
                        break
                    try:
                        chunk = json.loads(payload)
                        token = chunk["choices"][0]["delta"].get("content") or ""
                        if token:
                            yield token
                    except Exception as e:  # noqa: BLE001
                        log.debug("Skipping malformed chunk: %s", e)
    except Exception as e:  # noqa: BLE001
        log.exception("OpenAI stream failed")
        yield f"\n\n_Could not reach OpenAI: {e}_\n"


# ---------------------------------------------------------------------------
# Main endpoint — Server-Sent Events
# ---------------------------------------------------------------------------
@app.post("/chat/message")
async def chat_message(req: ChatRequest):
    if not req.message or not req.message.strip():
        raise HTTPException(status_code=400, detail="Empty message")

    subject, expert_name, badge, pulse, thinking_steps = classify(req.message)
    mode = (req.feature_hint or "deep").lower()

    async def event_stream():
        # 1. Reasoning trace — one step at a time so the UI can animate it.
        for idx, step in enumerate(thinking_steps):
            yield sse("thinking", {"text": step, "status": "active"})
            await asyncio.sleep(0.18)
            yield sse("thinking", {"text": step, "status": "done"})

        # 2. Expert badge.
        yield sse("expert", {
            "subject": subject,
            "name": expert_name,
            "badgeColor": badge,
            "pulseColor": pulse,
        })

        # 3. Streamed answer tokens.
        async for token in stream_tokens(req.message, mode):
            yield sse("content", {"token": token})

        # 4. Suggested follow-ups.
        yield sse("followups", {"items": followups_for(subject)})

        # 5. End-of-stream sentinel.
        yield sse("done", {"ok": True})

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@app.get("/health")
async def health():
    return JSONResponse({
        "status": "healthy",
        "openai_key_set": bool(OPENAI_API_KEY),
        "version": "0.1.0",
    })


@app.get("/")
async def root():
    return JSONResponse({
        "service": "StudyMate AI minimal LLM proxy",
        "endpoints": ["/chat/message (POST, SSE)", "/health"],
        "openai_key_set": bool(OPENAI_API_KEY),
    })


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("server:app", host="0.0.0.0", port=8000, reload=False)
