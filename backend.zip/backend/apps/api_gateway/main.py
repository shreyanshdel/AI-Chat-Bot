from fastapi import FastAPI, WebSocket, Depends
from fastapi.middleware.cors import CORSMiddleware
from apps.api_gateway.routers import auth, chat, vision, voice, tutor, knowledge
from core.config.settings import settings
from core.observability.logging import setup_logging

app = FastAPI(
    title="StudyMate AI - API Gateway",
    version="2.0.0",
    description="Frontier Agentic AI Tutoring Backend"
)

# Setup Observability
setup_logging()

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include Domain Routers
app.include_router(auth.router, prefix="/auth", tags=["Authentication"])
app.include_router(chat.router, prefix="/chat", tags=["Conversational AI"])
app.include_router(vision.router, prefix="/vision", tags=["Multimodal Vision"])
app.include_router(voice.router, prefix="/voice", tags=["Speech AI"])
app.include_router(tutor.router, prefix="/tutor", tags=["Pedagogical Tools"])
app.include_router(knowledge.router, prefix="/knowledge", tags=["Knowledge Graph"])

@app.get("/health")
async def health_check():
    return {"status": "healthy", "version": "2.0.0", "layers": "7/7 active"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
