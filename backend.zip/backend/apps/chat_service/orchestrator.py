from typing import TypedDict, List, Dict
from langgraph.graph import StateGraph, END
from agents.planner.agent import PlannerAgent
from agents.researcher.agent import ResearcherAgent
from agents.solver.agent import SolverAgent
from agents.teacher.agent import TeacherAgent
from agents.critic.agent import CriticAgent

class AgentState(TypedDict):
    query: str
    student_id: str
    plan: Dict
    context: List[str]
    solution: str
    draft: str
    critique: str
    final_output: str
    iteration: int

class Orchestrator:
    """
    Stateful Multi-Agent Orchestrator for autonomous tutoring.
    Implements the 7-step LangGraph DAG.
    """
    def __init__(self):
        self.planner = PlannerAgent()
        self.researcher = ResearcherAgent()
        self.solver = SolverAgent()
        self.teacher = TeacherAgent()
        self.critic = CriticAgent()
        
        self.builder = StateGraph(AgentState)
        
        # Add Nodes
        self.builder.add_node("plan", self.planner.execute)
        self.builder.add_node("research", self.researcher.execute)
        self.builder.add_node("solve", self.solver.execute)
        self.builder.add_node("compose", self.teacher.execute)
        self.builder.add_node("validate", self.critic.execute)
        
        # Set flow
        self.builder.set_entry_point("plan")
        self.builder.add_edge("plan", "research")
        self.builder.add_edge("research", "solve")
        self.builder.add_edge("solve", "compose")
        self.builder.add_edge("compose", "validate")
        
        # Conditional logic for Critic
        self.builder.add_conditional_edges(
            "validate",
            self._check_quality,
            {
                "rewrite": "compose",
                "deliver": END
            }
        )
        
        self.graph = self.builder.compile()

    def _check_quality(self, state: AgentState):
        if "REWRITE" in state["critique"] and state["iteration"] < 2:
            return "rewrite"
        return "deliver"

    async def run_query(self, query: str, student_id: str):
        initial_state = {
            "query": query,
            "student_id": student_id,
            "iteration": 0
        }
        return await self.graph.ainvoke(initial_state)
