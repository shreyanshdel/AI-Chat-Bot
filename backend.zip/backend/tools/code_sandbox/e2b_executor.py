import e2b
from typing import Dict, Any

class CodeSandbox:
    """
    Secure, isolated Python execution environment for academic solvers.
    Uses E2B for production-grade sandboxing.
    """
    def __init__(self, api_key: str = None):
        self.api_key = api_key

    async def run_computation(self, code: str) -> Dict[str, Any]:
        """
        Executes code in a secure cgroup-limited sandbox.
        Returns stdout, stderr, and any generated charts (base64).
        """
        async with e2b.Sandbox() as sandbox:
            # Install necessary packages if needed (cached in production)
            # await sandbox.install_packages(['numpy', 'sympy', 'matplotlib'])
            
            result = await sandbox.run_python(code)
            
            return {
                "stdout": result.stdout,
                "stderr": result.stderr,
                "results": result.results,
                "logs": result.logs
            }

    @staticmethod
    def wrap_math_problem(problem: str) -> str:
        """Helper to wrap a math doubt into a solvable SymPy script."""
        return f"""
import sympy
from sympy import symbols, solve, latex
x, y, z = symbols('x y z')
solution = solve({problem})
print(latex(solution))
        """
