from app.core.config.prompts import SystemPrompts
from app.integrations.openai_client import OpenAIClient

class TeacherAgent:
    """
    The pedagogical core of StudyMate AI.
    Synthesizes research and solutions into the 4-layer teaching structure.
    """
    def __init__(self):
        self.llm = OpenAIClient()

    async def execute(self, state: dict) -> dict:
        """
        Takes the query, research context, and solver results to build the final lesson.
        """
        prompt = (
            f"STUDENT QUERY: {state['query']}\n"
            f"VERIFIED CONTEXT: {state['context']}\n"
            f"SOLVER RESULTS: {state.get('solution', 'N/A')}\n"
            "INSTRUCTION: Synthesize this into a 4-layer explanation (Hook, Simple, Proper, Anchor)."
        )
        
        draft = await self.llm.generate(
            prompt=prompt,
            system_prompt=SystemPrompts.STUDYMATE_CORE,
            temperature=0.75
        )
        
        return {"draft": draft, "iteration": state.get("iteration", 0) + 1}
